import styled, {css} from 'styled-components'

const HomeComponent = styled.div`
  
`

export default HomeComponent
