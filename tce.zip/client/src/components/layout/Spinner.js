import React from 'react'
import SpinnerComponent from '../../StyledComponents/layout/Spinner'

const Spinner = () => {
  return (
    <SpinnerComponent />
  )
}

export default Spinner

